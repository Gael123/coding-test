The application was written in javascript es 6 and can be run by running 'node tweet.js',First I used the map function to get a new array from the json then iterated through and pushed it to the new array tweet.
Testing was done using console.log or calling on the makeTweet(movies,inputs),did this directly on the terminal by running node and pasting my code there,can also be done by running node tweet.js(much easier and readable)
the function makeTweet returns an array containing title ,year ,review and stars
